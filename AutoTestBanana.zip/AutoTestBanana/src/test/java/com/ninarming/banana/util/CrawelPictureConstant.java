package com.ninarming.banana.util;

public class CrawelPictureConstant {

	public static final String CRAWELPICTUREUSER="ninarming";
	public static final String CRAWELPICTUREPWD="test";
	public static final String TESTEDURL = "https://www.123rf.com.cn/";
	public static final String LOGINURL = "https://www.123rf.com.cn/login.php";
	public static final String SEARCHURL = "http://www.123rf.com.cn/search.php?keyword=";
	
	

}
