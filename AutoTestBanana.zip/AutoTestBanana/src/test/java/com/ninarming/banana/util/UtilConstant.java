package com.ninarming.banana.util;

public class UtilConstant {
	/************环境配置*********************/
	public static final String FFURL="D:/Program Files (x86)/Mozilla Firefox/firefox.exe";
	public static final String GKURL="D:/Program Files (x86)/Mozilla Firefox/geckodriver.exe";
	public static final String FFPROFILE="AutoTest";
	public static final String SEPARATIVESIGN = ">";

}
