package com.ninarming.banana.util;

public class FileProfileConstant {
	
	public static final String CRAWELPICTUREOBJECTFILE = "src/test/resources/CrawelPictureData/objectMap.properties";

}
